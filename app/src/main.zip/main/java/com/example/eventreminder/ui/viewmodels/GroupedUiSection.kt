package com.example.eventreminder.ui.viewmodels

data class GroupedUiSection(
    val header: String,
    val events: List<EventReminderUI>
)
